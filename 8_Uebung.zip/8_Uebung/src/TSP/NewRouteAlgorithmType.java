package TSP;

public enum NewRouteAlgorithmType {
    Reversed,
    NearestNeighbour
}
